using Microsoft.AspNetCore.Mvc;

namespace CharitySystem.Components
{
    public class NavigationMenuViewComponent : ViewComponent
    {
        public IViewComponentResult Invoke()
        {
            return Content("Hello from the Nav View Component");
        }
    }
}